
README for patch_image.pl
--------------------------------------
Marvell Flash Image Patch Tool v2.03.0002

This readme is for the source version of the tool.
Its focus is on how to execute the tool using a Strawberry Perl version. 
The parameters and what you can do with the tool are described in the 
the readme of the compiled version of the tool patch_image.exe. 

Installation
-------------
In order to be able to use patch_image.pl you need:
   - a Strawberry Perl installation (for Windows)
     recommended/tested versions: v5.22.01_32_64bit_int, v5.32.1_64
   - with Net::IPv4Addr v0.10 and Net::IPv6Addr v1.02 modules added from CPAN	 
   - a firmware image file matching your device 

Perl versions:
--------------
If you have a different Perl version (> 5.10) installed, chances are good that 
you will get the same results as long as the Net::IPv4/v6Addr modules are
compatible. 


Invocation
-----------
patch_image.pl <command line parameters>

The tool will check the command line parameters and fail with an error message
if it encounters unknown parameters, missing mandatory parameters or parameters
whose values are out of range.

-- End of readme
   

