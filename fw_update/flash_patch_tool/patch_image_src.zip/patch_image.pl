###############################################################################
#
# (C)Copyright 2017-2023 Marvell(R). All rights reserved 
# The following file is provided �as is� without any warranty, and is subject
# to the limited use license agreement by and between Marvell and you,
# your employer or other entity on behalf of whom you act.
# In the absence of such license agreement the following file is subject to
# Marvell�s standard Limited Use License Agreement.
#
###############################################################################

use strict;
use warnings;

use Getopt::Long qw (:config pass_through);
use Net::IPv6Addr 1.02;
use Net::IPv4Addr 0.10;
use Digest::MD5 qw (md5_hex);


use strict;

my %opt = ();
my @opt_ip;

our $Version = "v2.03.0002";
our $Toolname = "Marvell Flash Image Patch Tool";


my $DEFAULT_PATCH_ADDR = 0x1_0000;
my $DATA_PART_SIZE = 0x1_0000;
my $MBR_AREA = 0x1BE;	# 446
my $MBR_SIZE = 0x42;  	# 66 bytes
my $SPB_AREA = 0x180;
my $SPB_SIZE = 0x38;

my $_8MB = 0x80_0000;
my $UPD_ID = 0x2;	# id of unsecure data partition in SPB
my $TEMP_ID = 0x1;	# id of temporary partition in SPB

my @DSA_Tag = (0x40, 0xfa, 0xcf, 0x01);
my @DSA_Fill = (0x00, 0x01, 0x00, 0x00);

my $MSG_RMU_CFG_MAC_ADDR = 0xf301;
my $MSG_RMU_CFG_IPV4_ADDR = 0xf302;
my $MSG_RMU_CFG_IPV6_ADDR = 0xf303;

my $PRISTINE_MAC 	= '02:00:00:00:00:01';
my $DIE1_MAC  		= '02:00:00:01:00:01'; 
my $DIE2_MAC  		= '02:00:00:02:00:01'; 

my %DEFAULT_MAC_ADDRESSES = (1 => [$PRISTINE_MAC],
							 2 => [$PRISTINE_MAC],
							 3 => [$PRISTINE_MAC, $DIE1_MAC, $DIE2_MAC],
							 );

my $MAC_rgx = '(?<mac>[[:xdigit:]]{1,2}(?<delim>[:-]{0,1})(([[:xdigit:]]{1,2}\k<delim>){4})[[:xdigit:]]{1,2})';
my $ipv4_basic_rgx = '^\d+[.]\d+[.]\d+[.]\d+$';
my $devicenum_rgx1 = '(?<devnum>(0x(?:1[0-7]|[0-7])|(?:2[0-3]|1[6-9]|[0-7])))';
my $devicenum_rgx2 = '(?<devnum>(0x[0-9,A-F,a-f]|1[0-5]|[0-9]))';
my @devnum_rgx = ('', $devicenum_rgx1, $devicenum_rgx2, $devicenum_rgx2);
my @legal_devnum = ('', '0..7, 16..23', '0..15', '0..15');
my @MAC_bytes;
my @IP_bytes;
my $devnum;
my $delimiter = '';
my %valid_aesgen = (1 => 1, 2 => 1, 3 => 1);
my $pMBR;
my %typestr = ('N' => 'Secondary', 'M' => 'Primary', 'O' => 'Tertiary',  'D' => 'Data', 'T' => 'Temporary', 'P' => 'Quaternary');

my $ShowHelpFunc;
my $Toolversion = '';
my $Scriptname = '';
my $DIE_NOT_EXIT = 0;
my $ExitCode = 0;
my $QUIET_MODE = 0;
my $ImageType;

#-------------- Tool related common fucntions --------------------
sub StartupMsg {
	print "\n$Toolname $Toolversion\n\n";
}

sub SetToolInfo {
	my $name = shift;
	my $version = shift;
	my $pHelpFunc = shift;

	$ShowHelpFunc = $pHelpFunc;
	$Toolname = $name;
	if (defined ($version)) {
		$Toolversion = $version;
	}

	$Scriptname = $0;
	if ($Scriptname =~ /([^\\\/]+(\.\S+)?)$/) {
		$Scriptname = $1;
	}
}

sub Disable_exit {
	no warnings 'redefine';
	*CORE::GLOBAL::exit = sub (;$) {};
	$DIE_NOT_EXIT = 1;
};

sub Enable_exit {
	no warnings 'redefine';
	*CORE::GLOBAL::exit = \&CORE::exit;
	$DIE_NOT_EXIT = 0;
};

sub InstallDieHandler {
$SIG{__DIE__} = sub {
#						printf "Exception caught: DIE  - Eval: %d - DIE_NOT_EXIT: %d\n", $^S, $DIE_NOT_EXIT;
						return if ($^S);
#						printf "FATAL: %s\n", join ('', @_);
						if ($DIE_NOT_EXIT) {
							die (@_);
						}
						else {
							printf "\n%s\n",join ('', @_);
							exit ($ExitCode);
						}
					};
}

sub DieWithCode {
	my $code = shift;
	my $msg = shift || '';
	my $show_help = shift;
	my $insertedLF = '';

	$ExitCode = $code;
	if (defined ($show_help) && $show_help) {
		if (defined ($ShowHelpFunc)) {
			$ShowHelpFunc->("for $Scriptname", $show_help > 1);
		}
		else {
			DieWithCode (99, "ERROR:ShowHelp function not set/defined!\n");
		}
	}

	if ($code) {
		if (length ($Toolname) + length ($msg) > 72) {
			$insertedLF= "\n";
		}

		$msg = sprintf ("\n%s failed: %s%s\n", $Toolname, $insertedLF, $msg);
	}
	else {
		if (!$QUIET_MODE) {
			$msg = sprintf ("%s\n%s finished successfully.\n", $msg, $Toolname) ;
		}
		else {
			$msg = ' ';
		}
	}
	die ($msg);
}

#------------------------ Help and options handling ---------------------------


sub ShowHelp {
 my $for_script = shift;
   print <<EOHELP

Command line options $for_script:

-fwimage=s       - Image file to be used (mandatory)
-aesgen=n        - Specify Automotive Ethernet Switch generation (mandatory)
                   1=88Q5050           
                   2=88Q5072/88Q6113/88Q5040  
                   3=88Q515x/88Q5192/MVQ6223/MVQ6222 
-die=n           - specify which data partition shall be treated
                   in case of single-flash image for 88Q5192 
                   0=first die, 1=second, default:0 
-macaddress=s    - Program MAC address (format xxdxxdxxdxxdxxdxx)
                   (d is delimiter, either '-' or ':' or '' (empty))
                   or a file name containing one non-empty line with it
-show            - Display configured addresses
-devicenum       - Target device number (may also be given in hex (0x..))
-ip=s            - Configure IP address
                   IPV4 (format n1.n2.n3.n4, n1..4: 0..255) or
                   IPV6 (h1:..:nh or h1:..:h6:d1.d2.d3.d4)
                   may appear two times (for IPv4 and IPv6)
-clearall        - remove all entries for given device number
                   (really all entries when no device number is given)
-delete          - remove given entry from the list
                   (macaddress or ip for given device)
-patchaddr=x     - optionally patch at a different address
-provision_img=s - Image file (binary) to be used as provisioning data
-help|?          - Show this page and exit

EOHELP
;
}

sub UnknownParameter {
	$opt{__unknown__} = join (',' , @_);
}

sub HandleOptions {
    GetOptions (\%opt,
				'fwimage=s',
				'aesgen=i',
                'macaddress=s',
				'devicenum=s',
				'die=n',
				'ip=s@{1,2}',
                'show',
                'patchaddr=o',
				'provision_img=s',
				'delete',
				'clearall',
                'help|?',
				'<>' 		=> \&UnknownParameter,
				);
	my $pInfo;			

	if ($opt{__unknown__}) {
		if ($opt{__unknown__} =~ /^\S+=$/) {
			DieWithCode (1, sprintf ("ERROR:Option value missing: %s", $opt{__unknown__}), 1);
		}
		else {
			DieWithCode (1, sprintf ("ERROR:Unknown option: %s", $opt{__unknown__}), 1);
		}
	}

	if ($opt{help}) {
		DieWithCode (0, '', 1);
	}

	if ( !$opt{show} && !$opt{macaddress} && !$opt{ip} && !$opt{clearall} && !$opt{delete} &&!$opt{provision_img}) {
		DieWithCode (1, "ERROR:No command option (-macaddress, -show, -ip, -clearall -delete -provision_image) given!\n", 1);
	}


	if (defined $opt{aesgen}) {
		if (!exists $valid_aesgen{ $opt{aesgen} } ) {
			DieWithCode (1, sprintf ("Invalid value %d for option -aesgen : must be one of %s\n", 
							$opt{aesgen}, join (",", sort keys %valid_aesgen)), 1);
		}	
	}
	else {
		DieWithCode (1, "ERROR: Mandatory parameter -aesgen is missing!\n", 1);
	}

	if ( !$opt{fwimage} ) {
		DieWithCode (1, "ERROR:Mandatory parameter -fwimage is missing!\n", 1);
	}
	elsif ( !-e $opt{fwimage} ) {
		DieWithCode (3, sprintf ("ERROR:File %s not found\n", $opt{fwimage}));
	}
	elsif ( -z $opt{fwimage} ) {
		DieWithCode (3, sprintf ("ERROR:Firmware image file %s is empty\n", $opt{fwimage}));
	}
	elsif (-s $opt{fwimage} < ($DEFAULT_PATCH_ADDR | 0xFFFF) ) {
		DieWithCode (3, sprintf ("ERROR:File %s too small to be a patchable image! (%d bytes)\n", $opt{fwimage}, -s $opt{fwimage} ));
	}
		if (defined $opt{devicenum}) {
		if ($opt{devicenum} !~ /^$devnum_rgx[$opt{aesgen}]$/) {
			DieWithCode (4, sprintf ("ERROR:Illegal value for parameter -devicenum\n\tPossible values (aesgen=%d): %s\n",
							$opt{aesgen},$legal_devnum[$opt{aesgen}]) , 1);
		}					
		else {
			$devnum = eval ($opt{devicenum});
		}
	}

	if ( $opt{macaddress} || defined ($opt{ip})) {
		if ( ! defined ($opt{devicenum}) ) {
			DieWithCode (1, "ERROR:Mandatory parameter -devicenum is missing!\n", 1);
		}
	}

	if ($opt{clearall}) {
		if ($opt{delete}) {
			DieWithCode (1, "ERROR:Parameter -delete and -clearall cannot be used together!\n", 1);
		}
		if ( $opt{macaddress} || defined ($opt{ip})) {
			DieWithCode (1, "ERROR:Parameters -macaddress and -ip cannot be used together with -clearall!\n", 1);
		}
	}

	if ($opt{delete}) {
		if ( !defined $opt{macaddress} && !defined $opt{ip} ) {
			DieWithCode (1, "ERROR:Parameter -delete requires parameter(s) -macaddress and/or -ip!\n", 1);
		}
	}
	if ( $opt{macaddress}) {
		($delimiter, @MAC_bytes) = RetrieveMACAddress ($opt{macaddress});
	}
	if (defined $opt{provision_img}) {
		if ($opt{aesgen} < 3) {
			DieWithCode (1, "ERROR:Parameter -provision_image only allowed when aesgen is >=3!\n", 1);
		}
	}
	if ( defined($opt{ip}) ) {
		my @cnt = (0, 0);
		my $i = 0;
		foreach my $ip (@{$opt{ip}}) {
			if ($ip =~ /$ipv4_basic_rgx/) {
				if (is_ipv4 ($ip)) {
					@IP_bytes = split (/\./, $ip);
					$opt{ip}->[$i] = [@IP_bytes];
					$cnt[0]++;
				}
				else {
					DieWithCode (4, sprintf ("ERROR: %s is not a valid IPv4 address!\n", $ip));
				}
			}
			else {
				if (is_ipv6 ($ip)) {
					@IP_bytes = &Net::IPv6Addr::to_array ($ip);
					$opt{ip}->[$i] = [@IP_bytes];
					$cnt[1]++;
				}
				else {
					DieWithCode (4, sprintf ("ERROR: %s is neither a valid IPv4 nor a valid IPv6 address!\n", $ip));
				}	
			}
			if ( ($cnt[0] > 1) || ($cnt[1] > 1)) {
				DieWithCode (4, sprintf ("ERROR: You cannot specify two IP addresses of the same kind (IPv4/IPv6)!\n"));
			}
			$i++;
		}
	}

	my $pAllMBR = ReadAllMBRs ($opt{fwimage}, $opt{aesgen});
	$ImageType = getImageType ($pAllMBR);
	
	my $MBRIdx = 0;  # 0 == default == first MBR; 2 = first MBR die#1
	if (exists $opt{die}) {
		if ($opt{aesgen} != 3) {
			DieWithCode (1, "ERROR: Option -die only allowed with -aesgen=3 !\n", 1);
		}
		if ($ImageType ne 'SINGLE_FLASH') {
			printf "WARNING: Option -die only useful for single-flash images! Ignoring option for %s image\n", $ImageType;
			delete $opt{die};
		}	
		elsif ( ($opt{die} < 0) || ($opt{die} >1) ) {
			DieWithCode (1, sprintf ("ERROR: Illegal value %d for option -die (Valid: 0 or 1)!\n",$opt{die}), 1);
		}
		if (exists $opt{die}) {
			$MBRIdx = 2 * $opt{die};
		}	
	}	

	$pMBR = $pAllMBR->[$MBRIdx];
	if (!$pMBR->{valid} || !exists $pMBR->{Primary} || !exists $pMBR->{Data}) {
		DieWithCode (3, sprintf "Image %s has no valid MBR!\n", $opt{fwimage}); 
	}
	
	if (defined $opt{provision_img}) {
		my $fname = $opt{provision_img};
		if (!exists $pMBR->{valid_spb} || !$pMBR->{valid_spb}) {
			DieWithCode (3, sprintf "Image %s has no valid SPB - wrong image type?\n", $opt{fwimage}); 
		}
		if (!-e $fname){
			DieWithCode (3, sprintf "File for provisioning image %s does not exist\n", $fname); 
		}
		else{
			my $size = -s $fname;
			if ($size > 0x2_0000 - 0x2000) {
				DieWithCode (3, sprintf "Provisioning image %s is too big %d KB (>%d KB)\n", $fname, $size>>10, (0x2_0000 - 0x2000) >> 10); 
			}
		}	
	}

	
	if ($opt{patchaddr}) {
		if (OverlappingAdresses ($opt{patchaddr}, 0x1000, $pMBR)) {
			DieWithCode (4, sprintf ("ERROR: Specified patch address 0x%x overlaps non-Data partitions from MBR!\n", $opt{patchaddr}));
		}
		$DEFAULT_PATCH_ADDR = $opt{patchaddr};
	}
	else {
		if (exists $pMBR->{Data}) {
			$pInfo = $pMBR->{Data};
			$DEFAULT_PATCH_ADDR = $pInfo->{start};
			$DATA_PART_SIZE = $pInfo->{length};
		}
		else {
			DieWithCode (3, sprintf "Image %s has no data partition in MBR!\n", $opt{fwimage}); 
		}
	}	

}
#------------------- function to read and write files -----------------------------------------------------------
sub readFile {
    my $filename = shift (@_);
    my $maxsize = shift (@_);
	my $startaddr = shift (@_) || 0;
	my $filter_func = shift;

    my $content;
    my $chksum;
    my $size;
	my $version;
    if (-e $filename) {
        $size = -s $filename;
        if (defined ($maxsize) && $maxsize) {
            $size = $maxsize;
        }
        open (FILE, "<", $filename) or DieWithCode ($!, sprintf ("ERROR: Unable to read file %s!\n", $filename));
        binmode (FILE);
		if ($startaddr) {
			seek (FILE, $startaddr, 0);
		}
        sysread FILE, $content, $size;
        close FILE;
    }
    else {
        DieWithCode (3, sprintf ("ERROR:Unable to find file %s!\n", $filename))
    }

    if (defined ($content) && wantarray ) {
		if (defined $filter_func && (ref $filter_func eq 'CODE')) {
			$chksum = md5_hex ($filter_func->($content));
		}
		else {
			$chksum = md5_hex ($content);
		}
		$version =  getVersion (\$content);
		return ($content, $chksum, $version);

    }
    return $content;
}

sub writeFile {
    my $filename = shift (@_);
    my $content = shift (@_);
	$content = '' if (!defined ($content));
    my $size = length ($content);

    open (FILE, ">", $filename) or DieWithCode ($!, sprintf ("ERROR:Unable to open file for write %s!\n", $filename));
    binmode (FILE);
    my $bytes_written = syswrite FILE, $content, $size;
    close FILE;
    return ($bytes_written != $size);
}

sub getVersion {
	my $pContent = shift;
	#Version: e.g.  2.00.0034 (2017-07-27) - Copyright Marvell

	if ($$pContent =~ /(?<version>\d+\.\d{2}(\.\d{4,5}|\s+Rev\.\s+\d+))([^(]+)?(?<date>\([^)]+\))\s+-\s+Copyright\s+Marvell/) {
		return ("$+{version}  $+{date}");
	}
}
#------------------------------------------------------------------------------

sub OverlappingRegion {
	my $addr = shift || 0;
	my $size = shift;
	my $region_start = shift;
	my $region_len 	 = shift;
	my $MBRSize = 4096;

	my $overlap = 0;
	my $end = $addr + $size;
	$overlap += ($addr < $MBRSize);		# implicit region
	$overlap += ( ($addr >= $region_start) && ($addr < $region_start + $region_len) );
	$overlap += ( ($addr < $region_start) && ($end >= $region_start) );

	return ($overlap != 0);
}

sub OverlappingAdresses {
	my $addr = shift || 0;
	my $size = shift;
	my $p_valid_flashMBR = shift;
	my $overlap = 0;

	for ( my $i=0; $i < 4; $i++) {
		my $pMBRInfo = $p_valid_flashMBR->{partitions}[$i];
		if ( ($pMBRInfo->{type} ne 'Empty') && ($pMBRInfo->{type} ne 'Data')) {
			$overlap = OverlappingRegion ($addr, $size, $pMBRInfo->{start}, $pMBRInfo->{length});
			last if ($overlap);
		}
	}
	return ($overlap);
}

sub read_from_image_file {
	my $source = shift;
	my $file_offset = shift;
	my $len = shift;
	my $data;
	my $result = 0;
	my $non_aligned = $file_offset % 4 ? 4 - $file_offset % 4 : 0;
	
	open (FILE, '<', $source) || DieWithCode (4, sprintf ("Unable to open file %s for read!\n", $source));
	binmode (FILE);
	seek (FILE, $file_offset - $non_aligned, 0);
	sysread (FILE, $data, $len + $non_aligned);
	close (FILE);
	if (length($data) < $len) {
		printf ("Unable to read %d bytes from file %s starting at offset %d !\n", $len, $source, $file_offset);
		$result = 99;
		$data = pack ('C*', unpack ('C*', 0 x ($len+$non_aligned)));
	}
	
	return ($result, $data, $non_aligned)
}

sub hexdump {
	my $buf = shift;
	my $source = shift;
    my $offset = 0;

	printf ("MBR: %s\n",$source);
    foreach my $chunk (unpack "(a16)*", $buf)
    {
        my $hex = unpack "H*", $chunk; # hexadecimal magic
        $chunk =~ tr/ -~/./c;          # replace unprintables
        $hex   =~ s/(.{1,8})/$1 /gs;   # insert spaces
        printf "0x%08x (%05u)  %-*s %s\n", $offset, $offset, 36, $hex, $chunk;
        $offset += 16;
    }
}

sub AddPartitionInfo {
	my $p_MBRInfo = shift;
	my $i = shift;
	my $typecode = shift;
	my $start_addr = shift;
	my $len = shift;

	my $type = 'Empty';
	if ($typecode) {
		if (exists ($typestr{$typecode})) {
			$type = $typestr{$typecode};
		}
		else {
			$type = 'unknown (' . $typecode .')';
		}	
	}
	my $info = { idx => $i, typecode => $typecode, type => $type, start => $start_addr, length => $len };

	$p_MBRInfo->{partitions}[$i] = $info;
	if ($type ne 'Empty') {
		if (!exists ($p_MBRInfo->{$type})) {
			$p_MBRInfo->{$type} = $info;
		}
	}	
}	


sub getMBRInfo {
	my $verbose = shift;
	my $offset = shift;
	my $non_aligned = shift;
	my $data = shift;
	my %MBRInfo;
	my $mbr_id;
	my $buf;
	my $spb;


=pod
struct	mbr_part_s
{
	uint8_t	status;				/* reserved in bootrom */
	uint8_t	start_chs[3];		/* reserved in bootrom */
	uint8_t	type;				/* known in bootrom is
								 * 'M' for primary and
								 * 'N' for backup partitions
								 */
	uint8_t	end_chs[3];			/* reserved in bootrom */
	uint32_t	start_lba;		/* offset to start of
								 * partition in sectors
								 * (sectorsize = 256 byte)
								 */
	uint32_t	num_sectors;	/* number of sectors in
								 * partition
								 */
} __attribute__((packed));

Type1: < AES3
struct	mbr_s
{
	uint16_t			chksum  /* 16bit checksum  of partition field */	
	uint8_t				boot_strap_code[0x1BE]; /* reserved in bootrom */
	struct	mbr_part_s	partition[4];
	uint8_t				boot_signature_lo; /* fixed 0x55 */
	uint8_t				boot_signature_hi; /* fixed 0xaa */
} __attribute__((packed));

Type2: >= AES3
struct	mbr_s_aes3
{
	uint32_t			chksum  /* 32bit checksum of fields SPB..partition */
	uint8_t				boot_strap_code[0x17C]; /* reserved in bootrom */
	uint32_t			SPB[14];
	uint8_t				reserved[6];
	struct	mbr_part_s	partition[4];
	uint8_t				boot_signature_lo; /* fixed 0x55 */
	uint8_t				boot_signature_hi; /* fixed 0xaa */
} __attribute__((packed));
=cut

	
	$buf = substr ($data, $MBR_AREA, $MBR_SIZE);
	$spb = substr ($data, $SPB_AREA, $SPB_SIZE);
	
	my $with_spb = $spb ne chr(0) x $SPB_SIZE;

	if ($verbose) {
		hexdump ($buf, sprintf "0x%04x", $offset);
	}
	my $mbr_info = { idx => 99, typecode => 'X', type => 'MBR', start => 0, length => 512, raw => join (' ', unpack ('(H2)*', $data)) };

	# always read standard MBR entries
	my @mbr = unpack ('x' x $non_aligned .'((x4)(Ax3)(V)(V))4(v)', $buf);
	if ($verbose eq 'DEBUG') {
		for (my $idx = 0; $idx < scalar (@mbr); $idx++) {
			print ("$idx: $mbr[$idx]\n");
		}
	}

	my @partitions;
	$mbr_id = $mbr[12];
	my $type;
	my $typecode;

	$MBRInfo{id} = $mbr_id;
	$MBRInfo{MBR} = $mbr_info;
	$MBRInfo{valid} = ($mbr_id == 0xAA55);

	for (my $i=0; $i < 4; $i++) {
		my $idx = 3*$i;
		AddPartitionInfo (\%MBRInfo, $i, $mbr[$idx], $mbr[$idx+1]<<8, $mbr[$idx+2]<<8);
	}
	
	if ($MBRInfo{valid} && $with_spb ) {
		if ($verbose) {
			hexdump ($spb, sprintf "0x%04x", $offset);
		}
		my @spb_entries = map { sprintf "%x", $_ } unpack ('(V*)', $spb);
		my $last_idx = $#spb_entries;
		my $v;
		
		if ($verbose eq 'DEBUG') {
			for (my $idx = 0; $idx < scalar (@spb_entries); $idx++) {
				$v = oct '0x'.$spb_entries[$idx];
				my ($id, $flash_addr, $size_KB) = ($v >> 28, ($v & 0xFFFF_000), ($v & 0xFFF)<<2);
				if ($v) {
					printf ("%3d: v: %08x - id: %2d - offset: %06x - size: %4d KB\n", $idx, $v, $id, $flash_addr, $size_KB);
				}	
			}
		}
		my $first = 1; 
		my $found = 0;
		# search for UDP entry and TEMP partition, if valid SPB found
		for (my $idx = $last_idx; $idx >= 0; $idx--) {
			$v = oct '0x'.$spb_entries[$idx];
			my ($id, $flash_addr, $size) = ($v >> 28, $v & 0xFFFF_000, ($v & 0xFFF)<<12);
			my $info;
			if ($first && (( $id != 0xB) || !$flash_addr || $size) ) {
				print "WARNING: Found no or invalid SPB!\n"; 
				# invalid SPB
				$MBRInfo{valid_spb} = 0;	
				last;
			}	
			$MBRInfo{valid_spb} = 1;	
			$first = 0;
			if (($id == $UPD_ID) || ($id == $TEMP_ID)) {
				my $typecode = ('T','D')[$id == $UPD_ID];
				AddPartitionInfo (\%MBRInfo, $idx+0x10, $typecode, $flash_addr, $size);
				$found++;
				last if ($found == 2);   # stop if UPD and TEMP found
			}	
		}	
	}
	
	if ($verbose) {
		foreach my $part (@{$MBRInfo{partitions}}) {
			if ($part->{typecode}) {
				my $location = $part->{idx};
				$location = (sprintf ("%d", $location), 'SPB')[($location & 0x10) != 0];
				printf ("%4s: %-12s - Start addr. 0x%06x - Length 0x%06x\n", $location, $part->{type}, $part->{start}, $part->{length});
			}
			elsif (exists $part->{type}) {
				printf ("%4d: %-8s\n", $part->{idx}, $part->{type});
			}
		}
		printf ("MBR Id: 0x%x\n", $mbr_id);
	}
	
    return {%MBRInfo};
}

sub ReadAllMBRs {
	my $fname = shift;
	my $aesgen = shift;
	my $offset;
	my $mbr_valid;
	my ($result, $buf, $non_aligned);
	my %AllMBR;
	my $pAllMBR = [];
	
	my @offsets = (0x200, 0x0, 0x1000, 0x2000, 0x3000);

	if (!-e $fname) {
		DieWithCode (3, sprintf ("Unable to read FW image file %s\n", $fname));
	}
	my $imagelen = -s $fname;

	foreach $offset (@offsets) {
		($result, $buf, $non_aligned) = read_from_image_file ($fname, $offset, 512);
		my @data_w = unpack ('v*', $buf);
		$mbr_valid =  ($data_w[$#data_w] == 0xAA55);

		if ($mbr_valid) {
			$AllMBR{$offset} = getMBRInfo (0, $offset, $non_aligned, $buf);
			if ( ($offset != 0x200) && exists $AllMBR{0x200} && $AllMBR{$offset}->{MBR}->{valid_spb}) {
				DieWithCode (3, "ERROR: Invalid image - contains MBR for aesgen < 3 and aesgen >= 3!\n");
			}
			if (exists $AllMBR{$offset}->{Data}) {
				my $pInfo = $AllMBR{$offset}->{Data};
				if ( ($pInfo->{start} > $imagelen ) || 	($pInfo->{start} + $pInfo->{length} > $imagelen) ) {
					DieWithCode (3, sprintf "Image \"%s\" has an invalid MBR at offset 0x%04x!\nUnsecured Data Partition address 0x%x is not within image!\n", 
									$opt{fwimage}, $offset, $pInfo->{start}); 
				}
			}
		}
	}
	
	if (exists $AllMBR{0x200}) {	# old layout <= AES3
		push (@{$pAllMBR}, $AllMBR{0x0}, $AllMBR{0x200});
	}
	else {	# newer layout >= AES3
		if ($aesgen < 3) {
			DieWithCode (3, sprintf ("ERROR: FW image does not match specified -aesgen value %d!\n",$aesgen));
		}
		else {
			$offset = 0x0;
			while (exists $AllMBR{$offset}) {
				push (@{$pAllMBR}, $AllMBR{$offset});
				$offset += 0x1000;
			}
		}	
	}	
	return $pAllMBR;
}	
	
sub getImageType {
	my $pAllMBR = shift;
	my @ImageTypes = ('STD_ONE_CPU', 'DUAL_FLASH', 'SINGLE_FLASH');
	my $result = 3;
	my $MBRCnt = scalar @{$pAllMBR};
	
	if ($MBRCnt % 2) {	# odd number of MBRs is invalid
		DieWithCode (3, sprintf ("ERROR: Firmware image has an odd number (%d) of MBRs!\n       (wrong value for -aesgen?)\n", $MBRCnt));
	}	
	else {		
		# Primary MBR and backup MBR must be equal
		if ($pAllMBR->[0]->{MBR}->{raw} eq $pAllMBR->[1]->{MBR}->{raw}) {
			if (scalar @{$pAllMBR} == 4) {
				if ( $pAllMBR->[2]->{MBR}->{raw} eq $pAllMBR->[3]->{MBR}->{raw}) {	# second set of MBRs is equal	
					if ( $pAllMBR->[0]->{MBR}->{raw} eq $pAllMBR->[2]->{MBR}->{raw}) { # are first and second set of MBRs equal?
						$result = 1;	# yes -> DUAL_FLASH image 
					}		 
					else {
						$result = 2;	# no -> SINGLE_FLASH image for two dies	
					}
				}	
				else {
					DieWithCode (3, "ERROR: Primary and backup MBR for second die are different!\n");
				}
			}
			else {
				$result = 0;	# normal / standard single CPU image <= AES3
			}	
		}
		else {
			DieWithCode (3, "ERROR: Primary MBR differs from backup MBR!\n");
		}
	}
	return $ImageTypes[$result];
}	
#------------------------------------------------------------------------------

sub getRMUEntries {
	my $pContent = shift;
	my @RMUEntries = ();
	my $idx = $DEFAULT_PATCH_ADDR;
	my ($DSA, $len);
	my $valid = 1;

	while ($valid) {
		my $offset = $idx;
		($DSA, $len) = unpack ("(N)(n)", substr ($$pContent, $idx, 6));
		my $for_device = ($DSA >> 24) & 0x1F;

		$valid = (($DSA & 0xE0FF_FFFF) == unpack ('N', pack ("C4", @DSA_Tag)));
		if ($valid) {
			$idx += 6;
			my ($fill, $cmd) = unpack ("(N)(n)", substr ($$pContent, $idx, 6));
			$idx += 6;
			my $data = substr ($$pContent, $idx, $len-6);
			$idx += $len-6;

			push (@RMUEntries, { 	offset 	=> $offset,
									dsa 	=> $DSA,
									len 	=> $len,
									fill 	=> $fill,
									cmd 	=> $cmd,
									data 	=> $data,
									device  => $for_device
								});
		}
	}
	return (@RMUEntries);
}

sub ParseRMUEntries {
	my $pRMUEntries = shift;
	my $show = shift;
	my $msg;
	my $result;
	my @data;
	my %devices;
	my %entries;
	my $mac;
	my $ip;
	my $pristine_mac = 0;
	my $invalid_mac_found = 0;
	my $num_mac_addr = 0;
	my $deleted = 0;
	my $cnt = 0;
	my $idx = 0;
	my $pInfo;
	my $size = 0;
	my $die = $opt{die} // 0;
	my $MAC_to_compare;

	foreach my $pEntry (@{$pRMUEntries}) {
		next if ($pEntry->{delete});
		$devices{$pEntry->{device}} += 1;
		$cnt++;
		my $for_device = $pEntry->{device};
		if (!defined $entries{$for_device}) {
			$entries{$for_device} = [];
		}
		$size += $pEntry->{len};
		if ( ($pEntry->{cmd} == $MSG_RMU_CFG_MAC_ADDR) && ($pEntry->{len} == 12)) {
			@data = getCurrentMAC ($pEntry);
			printf "Device#: %2d   MAC address:  %s\n", $for_device, join (':', @data) if ($show);
			$mac = join (':', @data);
			$pInfo = [$pEntry, 'MAC_ADDR', $mac];
			$num_mac_addr++;
			if (!$pristine_mac && !$idx) { # only once at start
				$MAC_to_compare = $DEFAULT_MAC_ADDRESSES{$opt{aesgen}}->[($ImageType eq 'SINGLE_FLASH') + $die];
				$pristine_mac = ($mac eq $MAC_to_compare);
			}
			$invalid_mac_found += (($mac eq $PRISTINE_MAC) && ($idx > 0));
		}
		elsif ( ($pEntry->{cmd} == $MSG_RMU_CFG_IPV4_ADDR) && ($pEntry->{len} == 10)) {
			@data = getCurrentIPv4 ($pEntry);
			my $ip = join ('.', @data);
			printf "Device#: %2d   IPv4 address: %s\n", $for_device, $ip if ($show);
			$pInfo = [$pEntry, 'IP_V4', $ip];
		}
		elsif ( ($pEntry->{cmd} == $MSG_RMU_CFG_IPV6_ADDR) && ($pEntry->{len} == 22)) {
			@data = getCurrentIPv6 ($pEntry);
			my $ip = join (':', @data);
			printf "Device#: %2d   IPv6 address: %s\n", $for_device, $ip if ($show);
			$pInfo = [$pEntry, 'IP_V6', $ip];
		}
		else {
			$result = 5;
			$msg = sprintf ("ERROR: Unknown entry - Offset: 0x%04x Cmd: 0x%04x Length: %d\n",
							$pEntry->{offset}, $pEntry->{cmd}, $pEntry->{len});
			last;
		}

		push (@{$entries{$for_device}}, $pInfo);
		
		$idx++;
	}
	if ($size > $DATA_PART_SIZE) {
		# THIS should not occur!
		$result = 4;
		$msg .= sprintf ("\nERROR: Config data size %d exceeds limit of %d!\n", $size, $DATA_PART_SIZE);
	}	
	else {
		if (!$show) {   # plausibility check mode
			if (	$invalid_mac_found 
				|| ($pristine_mac && ($num_mac_addr == 1) && (scalar (@{$entries{0}}) > 1) ) ) {
				$result = 9;
				$msg .= sprintf ("\nERROR: Invalid configuration due to the use of default MAC address %s!\n", $MAC_to_compare);
				$msg .= "(A valid configuration must have a different MAC address)\n\n";
			}
			if ($pristine_mac && ($num_mac_addr > 1) ) {
				$msg .= sprintf ("\nWARNING: Removing entries for device 0 with default MAC address %s!\n", $MAC_to_compare);
				foreach my $pEntry (@{$entries{0}}){
					$pEntry->[0]->{delete} = 1;
					$deleted++;
				}
			}
			foreach my $devid (keys %entries) {
				my @cfg_parts = map { $_ -> [1] } @{$entries{$devid}};
				if ( $devid && (grep (/MAC_ADDR/, @cfg_parts) == 0 ) ) {
					$msg .= sprintf ("\nWARNING: Problematic configuration for device id %d due to missing MAC address!\n", $devid);
					$msg .= "(A valid configuration should have a MAC address)\n\n";
				}
			}
		}	
		else {
			if (scalar (@{$pRMUEntries}) == 0) {
				printf "%s\n\n", "Empty configuration";
			}
		}
		# check if any entries do not match the device id restriction set by aesgen
		foreach my $devid (keys %entries) {
			if ($devid !~ /^$devnum_rgx[$opt{aesgen}]$/) {
				$msg .= sprintf ("WARNING: Device id %d in configuration is not valid for aesgen=%d !\n", $devid, $opt{aesgen});
			}	
		}	
	}	
	return ($deleted, $result, $msg);
}

sub patchContent {
	my $pContent = shift;
	my $pEntry = shift;
	my $newOffset = shift;

	$pEntry->{dsa} &= 0xE0FF_FFFF;
	$pEntry->{dsa} |= ($pEntry->{device} << 24);

	my $buf = pack ("NnNnC*", $pEntry->{dsa}, $pEntry->{len}, $pEntry->{fill}, $pEntry->{cmd}) . $pEntry->{data};
	my $len = length ($buf);
	$pEntry->{offset} = $newOffset if (defined $newOffset);
	my $addr = sprintf ("%x", $pEntry->{offset});
	if (! exists $pEntry->{delete} || !$pEntry->{delete} ) {
		substr ($$pContent, $pEntry->{offset}, $len, $buf);
	}
	return $len;
}

sub getTargetEntry {
	my $pRMUEntries = shift;
	my $TargetCmd = shift;
	my $TargetLen = shift;
	my $TargetDev = shift;
	my $result;
	my $idx = -1;

	foreach my $pEntry (@{$pRMUEntries}) {
		if (   (!exists $pEntry->{delete} || !$pEntry->{delete})
			&& ($pEntry->{cmd} == $TargetCmd)
			&& ($pEntry->{len} == $TargetLen) ) {
				$result = $pEntry;
				if (defined $TargetDev) {
					if ($pEntry->{device} != $TargetDev) {
						undef ($result);
					}
				}
				last if (defined $result);
			}
		$idx++;
	}
	undef $idx if (!defined $result);
	return ($result, $idx);
}

sub AddEntry {
	my $pRMUEntries = shift;
	my $cmd = shift;
	my $len = shift;
	my $devicenum = shift;
	my $idx = 0;
	$devicenum = -1 if (!defined $devicenum);

	my $offset;
	my $pLastEntry;

	foreach my $pEntry (@{$pRMUEntries}) {
		if (!exists $pEntry->{delete} || !$pEntry->{delete}) {
			$pLastEntry = $pEntry;
		}
	}
	if ($pLastEntry) {
		$offset = $pLastEntry->{offset} + $pLastEntry->{len} + 6;
	}
	else {
		$offset = $DEFAULT_PATCH_ADDR;
	}


	my $newEntry =  { offset 	=> $offset,
					dsa 	=> unpack ('N', pack ('C4', @DSA_Tag)),
					len 	=> $len,
					fill 	=> unpack ('N', pack ('C4', @DSA_Fill)),
					cmd 	=> $cmd,
					data 	=> undef,
					device  => $devicenum,
				  };

	$idx = scalar (@{$pRMUEntries});	# number of entries before push is idx for push....
	push (@{$pRMUEntries}, $newEntry);
	return ($newEntry, $idx);
}

sub ClearAllEntries {
	my $pRMUEntries = shift;
	my $devnum = shift;
	my $deleted = 0;
	my $pEntry;

	foreach $pEntry (@{$pRMUEntries}) {
		if (!defined $devnum || ($pEntry->{device} == $devnum) ) {
			$pEntry->{delete} = 1;
			$deleted++;
		}
	}

	return $deleted;
}

sub byDev_and_cmd {

	my $va = !(!exists $a->{delete} || !$a->{delete});
	my $vb = !(!exists $b->{delete} || !$b->{delete});
	my $cmp = $va <=> $vb;
	$cmp = $a->{device} <=> $b->{device} if (!$cmp);
	$cmp = $a->{cmd} <=> $b->{cmd} if (!$cmp);
	return $cmp;
}

sub	DeleteFromContent {
	my $pRMUEntries = shift;
	my $pContent = shift;
	my $fillsize = 0;
	my $offset = $DEFAULT_PATCH_ADDR;

	# sort non-deleted entries by devnum and cmd
	@{$pRMUEntries} = sort byDev_and_cmd @{$pRMUEntries};

	#try to ensure that an RMU entry is the first entry
	# try to find any MACaddr entry
	my ($pTargetEntry, $idx) = getTargetEntry ($pRMUEntries, $MSG_RMU_CFG_MAC_ADDR, 12, undef);

	# splice found/added entry to be the first one...
	if (defined $idx && $idx) {	# if it is not the first entry...
		my $pEntry2Move = splice(@{$pRMUEntries}, $idx, 1);
		unshift (@{$pRMUEntries}, $pEntry2Move);
	}

	$idx = 0;
	while ($idx < scalar (@{$pRMUEntries}) ){
		my $pEntry = $pRMUEntries->[$idx];
		
		if ($pEntry->{delete}) {
			$fillsize += patchContent ($pContent, $pEntry, $offset);
			splice (@{$pRMUEntries}, $idx, 1);
		}
		else {
			$offset += patchContent ($pContent, $pEntry, $offset);
			$idx++;
		}
	}

	my $filler = "\xff" x $fillsize;
	substr ($$pContent, $offset, $fillsize, $filler);

	return 1;
}
#------------------ M A C ------------------------

sub macaddr2bytearray {
	my $macaddress = shift;
	my @MAC_bytes;
	my $delim;

	if ($macaddress =~ /$MAC_rgx/)  {
		$macaddress = $+{mac};
		$delim = $+{delim};
		@MAC_bytes = ($macaddress =~ /(..)$delim?/g);
		@MAC_bytes = splice (@MAC_bytes, 0, 6);
	}
	return @MAC_bytes;
}

sub RetrieveMACAddress {
	my $macaddress = shift;
	my @MAC_bytes;
	my $delim = '';
	my $filecontent;
	my $from_file = 0;
	my $msg;

	if (-e $macaddress) {
		$from_file = 2;
		my @data = readFile ($macaddress);
		$filecontent = shift (@data);
		if ($filecontent =~ /^\s*(MAC\s*address\s*=\s*)?(?<mac>\S+)/s) {
			$macaddress = $+{mac};
			$from_file--;
		}
	}
	@MAC_bytes = macaddr2bytearray ($macaddress);
	if (!scalar (@MAC_bytes)) {
		if ($from_file > 1) {
			DieWithCode (3, sprintf ("ERROR:%s does not contain a valid MAC address!\n", $macaddress));
		}
		else {
			DieWithCode (4, sprintf "\nERROR:%s is not a valid MAC address!\nMust be 6 hex bytes, optionally separated by either : or - ", $macaddress);
		}
	}
	return ($delim, @MAC_bytes);
}

sub getCurrentMAC {
	my $pEntry = shift;
	my @stored_mac;

	@stored_mac = unpack ("(H2)6", $pEntry->{data});

	if (wantarray) {
		return (@stored_mac);
	}
	else {
		return (join ('', @stored_mac));
	}
}


sub patchMAC {
	my $pContent = shift;
	my $pTargetEntry = shift;
	my $devnum = shift;;
	my $pMAC_byte_array = shift;

	$pTargetEntry->{data} = pack ("C*", map { hex ($_) } @{$pMAC_byte_array});
	$pTargetEntry->{device} = $devnum;

	patchContent ($pContent, $pTargetEntry);
}


#------------------ I P V 4------------------------
sub getCurrentIPv4 {
	my $pEntry = shift;
	my @stored_ip;

	@stored_ip = unpack ("(C)4", $pEntry->{data});

	if (wantarray) {
		return (@stored_ip);
	}
	else {
		return (join ('', @stored_ip));
	}
}

sub patchIPv4 {
	my $pContent = shift;
	my $pTargetEntry = shift;
	my $devnum = shift;;
	my $pIP_bytes= shift;

	$pTargetEntry->{data} = pack ("C*", @{$pIP_bytes});
	$pTargetEntry->{device} = $devnum;

	patchContent ($pContent, $pTargetEntry);
}

sub is_ipv4
{
    my $r;
    eval {
		$r = &Net::IPv4Addr::ipv4_chkip (@_);
    };
    if ($@) {
		return undef;
    }
    return $r;
}

#------------------ I P V 6------------------------

sub getCurrentIPv6 {
	my $pEntry = shift;
	my @stored_ip;

	@stored_ip = unpack ("(H4)8", $pEntry->{data});

	if (wantarray) {
		return (@stored_ip);
	}
	else {
		return (join ('', @stored_ip));
	}
}

sub patchIPv6 {
	my $pContent = shift;
	my $pTargetEntry = shift;
	my $devnum = shift;;
	my $pIP_bytes = shift;

	$pTargetEntry->{data} = pack ("n*", map { hex ($_) } @{$pIP_bytes});
	$pTargetEntry->{device} = $devnum;

	patchContent ($pContent, $pTargetEntry);
}

sub is_ipv6
{
    my $r;
    eval {
		$r = &Net::IPv6Addr::ipv6_chkip (@_);
    };
    if ($@) {
		return undef;
    }
    return $r;
}

sub HandleEntry {
	my $pRMUEntries = shift;
	my $pContent = shift;
	my $pInfo = shift;
	my @currentdata;
	my $mustPatch = 0;
	my $deleted = 0;
	my $patched = 0;

	my ($pTargetEntry, $idx) = getTargetEntry ($pRMUEntries, $pInfo->{cmd}, $pInfo->{len}, $pInfo->{devnum});

	if (!$pTargetEntry && !$pInfo->{delete}) {
		($pTargetEntry, $idx) = AddEntry ($pRMUEntries, $pInfo->{cmd}, $pInfo->{len}, $pInfo->{devnum});
		$mustPatch++;
	}
	elsif ($pInfo->{delete}) {
		if ($pTargetEntry) {
			$pTargetEntry->{delete} = 1;
			$deleted++;
		}
	}
	else {
		@currentdata = $pInfo->{currfunc}->($pTargetEntry);
		my $s1 = join ('-', map { uc $_ } @currentdata);
		my $s2 = join ('-', map { uc $_ } @{$pInfo->{newdata}});

		$mustPatch += $s1 ne $s2;
	}
	if ( $mustPatch ) {
		$pInfo->{patchfunc}-> ($pContent, $pTargetEntry, $pInfo->{devnum}, $pInfo->{newdata});
		$patched++;
	}
	return ($deleted, $patched);
}
#------- P R O V I S I O N  Image  ------------------------
sub PatchProvisionImage {
	my $pFW = shift;
	my $pProvisionImage = shift;
	my $pMBR = shift;
	my $success = 0;
	
	my $patch_addr;
	my $temp_size;
	my $target_size;
	my $append_size;
	my $fill;
	
	# get patch addr of  'T' partition
	if (exists $pMBR->{Temporary}) {
		$patch_addr = $pMBR->{Temporary}->{start};
		$temp_size = $pMBR->{Temporary}->{length};
	}	
	if  (defined $patch_addr && defined $temp_size && $patch_addr && $temp_size) {
		$target_size = $patch_addr + $temp_size;
		$patch_addr += 0x2000;
		$append_size = $target_size - length $$pFW;	
		$fill = chr(0xFF) x $temp_size;
		
		if ($append_size > 0) {
			# append missing area filled with 0xff
			$$pFW .= chr (0xFF) x $append_size;
			printf "Increasing image size to %d\n", $target_size;
		}
		# replace area to be patched with 0xFF to overwrite any previous attempts/versions
		substr ($$pFW, $patch_addr-0x2000, $temp_size, $fill);
		
		# then patch the provisioning data 
		substr ($$pFW, $patch_addr, length $$pProvisionImage, $$pProvisionImage);
		
		printf "Sucessfully patched provisioning image of %d bytes to offset 0x%x\n", length $$pProvisionImage, $patch_addr;
		$success++;
	}	
	return $success;
}

sub CheckForProvisioningImage  {
	my $pFW = shift;
	my $pMBR = shift;
	my $temp_addr;
	my $temp_size;
	my $prov_area;
	my $k = 0;
	my $size = 0;
	
	if (defined $pFW && defined $$pFW && defined $pMBR) {
		# get patch addr of  'T' partition
		if (exists $pMBR->{Temporary}) {
			$temp_addr = $pMBR->{Temporary}->{start};
			$temp_size = $pMBR->{Temporary}->{length};
		}
		if  ( defined $temp_addr && defined $temp_size && $temp_size) {	
			# no check for patch_addr as it is dependent on temp_addr
			if (length $$pFW >= $temp_addr + $temp_size) {		
				# look for non-0xFF data starting at patch_addr for max. 120 KB
				$prov_area = substr ($$pFW, $temp_addr + 0x2000, 0x2_0000 - 0x2000);	# 120KB part

				# find last non-FF byte = first non-FF byte from then end
				$k = length ($prov_area) - 1;
				while (($k >= 0) && (substr ($prov_area, $k, 1) eq "\xff") ) {
					$k--;
				}
				$size = $k+1;
			}
		}	
	}	
	return $size;
}	

#------- M A I N ------------------------
my $current_MAC;
my $current_IP;
my $current_device;
InstallDieHandler();

SetToolInfo ("Marvell Flash Image Patch Tool", $Version, \&ShowHelp);
StartupMsg ();

HandleOptions();

my($content, $chkksum, $FWVersion) = readFile ($opt{fwimage});
my @RMUEntries = getRMUEntries(\$content);

#if (scalar (@RMUEntries) == 0) {
#	DieWithCode (5, sprintf ("ERROR: Empty configuration found at defined offset 0x%06x!\n", $DEFAULT_PATCH_ADDR));
#}

my $patched = 0;
my $deleted = 0;
my $pInfo;

if (defined ($opt{macaddress})) {
	if ($opt{macaddress}) {
		$pInfo = {	cmd => $MSG_RMU_CFG_MAC_ADDR,
					len => 12,
					devnum => $devnum,
					currfunc => \&getCurrentMAC,
					patchfunc => \&patchMAC,
					newdata => \@MAC_bytes,
					delete => $opt{delete} || 0,
				 };

		my @result = HandleEntry (\@RMUEntries, \$content, $pInfo);
		$deleted += $result[0];
		$patched += $result[1];
	}
}

if (defined ($opt{ip})) {
	foreach my $p_ip (@{$opt{ip}}) {
		if (scalar (@{$p_ip}) == 4) {
			$pInfo = {	cmd => $MSG_RMU_CFG_IPV4_ADDR,
						len => 10,
						devnum => $devnum,
						currfunc => \&getCurrentIPv4,
						patchfunc => \&patchIPv4,
						newdata => $p_ip,
						delete => $opt{delete} || 0,
					};
		}
		else {
			$pInfo = {	cmd => $MSG_RMU_CFG_IPV6_ADDR,
						len => 22,
						devnum => $devnum,
						currfunc => \&getCurrentIPv6,
						patchfunc => \&patchIPv6,
						newdata => $p_ip,
						delete => $opt{delete} || 0,
					};
		}

		my @result = HandleEntry (\@RMUEntries, \$content, $pInfo);
		$deleted += $result[0];
		$patched += $result[1];
	}
}

# check validity of entries
my ($removed, $result, $msg) = ParseRMUEntries (\@RMUEntries, 0);	# silent check
$deleted += $removed;

if ($deleted || $opt{clearall}) {
	if ($opt{clearall}) {
		$deleted = ClearAllEntries (\@RMUEntries, $devnum);
	}
	if ($deleted) {
		$patched = DeleteFromContent (\@RMUEntries, \$content);
		my @strings = ('entry','entries');
		printf "\nDeleted %d configuration %s\n\n", $deleted, $strings[$deleted != 1];
	}
}

if ($opt{provision_img}) {
	# $pMBR set by HandleOptions
	my $provision_image = readFile ($opt{provision_img});
	$patched += PatchProvisionImage (\$content, \$provision_image, $pMBR);
}

if (!$result) {
	if ($patched) {
		if (writeFile ($opt{fwimage}, $content) == 0) {
			printf "Successfully wrote patched image file to %s\n\n", $opt{fwimage};
		}
	}
	else {
		if ($opt{macaddress} || $opt{ip}) {
			printf "No change - image file %s not updated\n\n", $opt{fwimage};
		}
	}

	if ($FWVersion) {
		printf ("Image: %s - Version: %s\n", $opt{fwimage}, $FWVersion);
	}

	($removed, $result, $msg) = ParseRMUEntries (\@RMUEntries, $opt{show});
	if ($opt{show}) {
		my $size = CheckForProvisioningImage (\$content, $pMBR);
		if ($size) {
			print ( ("\nImage ", sprintf ("\nImage for die#%d ", $opt{die} // 0) )[$ImageType eq 'SINGLE_FLASH']);
			printf "contains %d bytes of provisioning data\n", $size;
		}	
	}
}

if ($result) {
	DieWithCode ($result, $msg);
}
else {
	DieWithCode (0, $msg);
}

__END__
